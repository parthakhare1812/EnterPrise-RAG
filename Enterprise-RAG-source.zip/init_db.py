
from app.database import initialize_database, check_database_connection


def main():
    print("Initializing Enterprise RAG...")

    if not check_database_connection():
        raise SystemExit("Neon connection failed.")

    initialize_database()

    print("Database initialized successfully.")
    print("Created application tables:")
    print("- documents")
    print("- conversations")
    print("- messages")
    print("- approvals")
    print("- audit_logs")


if __name__ == "__main__":
    main()

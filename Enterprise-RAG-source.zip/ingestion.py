
import hashlib
import io
import json
import logging
import re
from functools import lru_cache
from pathlib import Path

import boto3
import fitz
from botocore.config import Config
from docx import Document as DocxDocument
from pinecone import Pinecone
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.config import settings


logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def get_bedrock_client():
    return boto3.client(
        "bedrock-runtime",
        region_name=settings.AWS_REGION,
        config=Config(
            retries={"max_attempts": 3, "mode": "standard"},
            connect_timeout=10,
            read_timeout=60
        )
    )


@lru_cache(maxsize=1)
def get_pinecone_client():
    return Pinecone(api_key=settings.PINECONE_API_KEY)


@lru_cache(maxsize=1)
def get_pinecone_index():
    client = get_pinecone_client()
    description = client.describe_index(settings.PINECONE_INDEX_NAME)

    if description.dimension != settings.EMBEDDING_DIMENSIONS:
        raise ValueError(
            f"Pinecone dimension mismatch: expected "
            f"{settings.EMBEDDING_DIMENSIONS}, "
            f"received {description.dimension}"
        )

    return client.Index(settings.PINECONE_INDEX_NAME)


def calculate_hash(file_bytes: bytes) -> str:
    return hashlib.sha256(file_bytes).hexdigest()


def save_local_file(
    file_bytes: bytes,
    filename: str,
    document_id: str
) -> str:
    directory = settings.UPLOAD_DIR / document_id
    directory.mkdir(parents=True, exist_ok=True)

    safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", Path(filename).name)

    if not safe_name:
        safe_name = "document"

    path = directory / safe_name
    path.write_bytes(file_bytes)

    return str(path)


def delete_local_file(storage_path: str):
    path = Path(storage_path)

    if path.exists() and path.is_file():
        path.unlink()

    if path.parent.exists():
        try:
            path.parent.rmdir()
        except OSError:
            pass


def extract_text(file_bytes: bytes, filename: str) -> str:
    extension = Path(filename).suffix.lower()

    if extension == ".pdf":
        with fitz.open(stream=file_bytes, filetype="pdf") as pdf:
            if pdf.is_encrypted:
                raise ValueError("Password-protected PDFs are not supported")

            content = "\n".join(
                page.get_text("text")
                for page in pdf
            )

    elif extension == ".docx":
        document = DocxDocument(io.BytesIO(file_bytes))

        parts = [
            paragraph.text
            for paragraph in document.paragraphs
        ]

        for table in document.tables:
            for row in table.rows:
                parts.append(
                    " | ".join(cell.text for cell in row.cells)
                )

        content = "\n".join(parts)

    elif extension == ".txt":
        try:
            content = file_bytes.decode("utf-8-sig")
        except UnicodeDecodeError as error:
            raise ValueError(
                "Text file must use UTF-8 encoding"
            ) from error

    else:
        raise ValueError("Unsupported document format")

    content = content.replace("\x00", "")
    content = re.sub(r"[ \t]+", " ", content)
    content = re.sub(r"\n[ \t]+", "\n", content)
    content = re.sub(r"\n{3,}", "\n\n", content).strip()

    if not content:
        raise ValueError(
            "No extractable text found. Scanned PDFs require OCR."
        )

    return content


def chunk_text(content: str) -> list[str]:
    size = settings.CHUNK_SIZE
    overlap = settings.CHUNK_OVERLAP

    if size <= 0 or overlap < 0 or overlap >= size:
        raise ValueError("Invalid chunk configuration")

    chunks = []
    start = 0
    content_length = len(content)

    while start < content_length:
        end = min(start + size, content_length)

        if end < content_length:
            boundary = max(
                content.rfind("\n", start, end),
                content.rfind(". ", start, end),
                content.rfind(" ", start, end)
            )

            if boundary > start + size // 2:
                end = boundary + 1

        chunk = content[start:end].strip()

        if chunk:
            chunks.append(chunk)

        if end >= content_length:
            break

        start = max(end - overlap, start + 1)

    return chunks


@retry(
    retry=retry_if_exception_type(Exception),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    reraise=True
)
def generate_embedding(content: str) -> list[float]:
    response = get_bedrock_client().invoke_model(
        modelId=settings.BEDROCK_MODEL_ID,
        body=json.dumps({
            "inputText": content,
            "dimensions": settings.EMBEDDING_DIMENSIONS,
            "normalize": True
        }),
        contentType="application/json",
        accept="application/json"
    )

    result = json.loads(response["body"].read())
    embedding = result.get("embedding")

    if not embedding:
        raise ValueError("Bedrock returned an empty embedding")

    if len(embedding) != settings.EMBEDDING_DIMENSIONS:
        raise ValueError(
            f"Invalid embedding dimensions: {len(embedding)}"
        )

    return embedding


def index_document(
    chunks: list[str],
    document_id: str,
    filename: str
):
    index = get_pinecone_index()
    batch_size = 100

    try:
        for batch_start in range(0, len(chunks), batch_size):
            batch = chunks[batch_start:batch_start + batch_size]

            vectors = []

            for offset, chunk in enumerate(batch):
                position = batch_start + offset

                vectors.append({
                    "id": f"{document_id}-{position}",
                    "values": generate_embedding(chunk),
                    "metadata": {
                        "document_id": document_id,
                        "filename": filename,
                        "chunk_index": position,
                        "text": chunk
                    }
                })

            index.upsert(
                vectors=vectors,
                namespace=settings.PINECONE_NAMESPACE
            )

            logger.info(
                "Indexed document %s: %s/%s chunks",
                document_id,
                min(batch_start + len(batch), len(chunks)),
                len(chunks)
            )

    except Exception:
        logger.exception(
            "Indexing failed for document %s. Cleaning up vectors.",
            document_id
        )

        try:
            delete_document_vectors(document_id)
        except Exception:
            logger.exception(
                "Vector cleanup failed for document %s",
                document_id
            )

        raise


def delete_document_vectors(document_id: str):
    get_pinecone_index().delete(
        filter={
            "document_id": {"$eq": document_id}
        },
        namespace=settings.PINECONE_NAMESPACE
    )


def process_document(
    file_bytes: bytes,
    filename: str,
    document_id: str
) -> int:
    content = extract_text(file_bytes, filename)
    chunks = chunk_text(content)

    if not chunks:
        raise ValueError("Document contains no valid chunks")

    index_document(
        chunks=chunks,
        document_id=document_id,
        filename=filename
    )

    return len(chunks)


from functools import lru_cache
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


PROJECT_ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    APP_NAME: str = "Enterprise RAG"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    API_PREFIX: str = "/api/v1"

    DATABASE_URL: str

    AWS_REGION: str = "ap-south-1"
    BEDROCK_MODEL_ID: str = "amazon.titan-embed-text-v2:0"
    BEDROCK_CHAT_MODEL_ID: str = ""
    EMBEDDING_DIMENSIONS: int = 1024

    PINECONE_API_KEY: str
    PINECONE_INDEX_NAME: str = "enterprise-rag"
    PINECONE_NAMESPACE: str = "enterprise-documents"

    UPLOAD_DIR: Path = PROJECT_ROOT / "uploads"
    MAX_UPLOAD_SIZE_MB: int = 20
    ALLOWED_EXTENSIONS: list[str] = [".pdf", ".docx", ".txt"]

    CHUNK_SIZE: int = 1200
    CHUNK_OVERLAP: int = 200

    RETRIEVAL_TOP_K: int = 5
    SIMILARITY_THRESHOLD: float = 0.35

    RIUS_ENDPOINT: str = ""
    RIUS_API_KEY: str = ""

    LANGGRAPH_CHECKPOINT_ENABLED: bool = True

    model_config = SettingsConfigDict(
        env_file=str(PROJECT_ROOT / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )

    @field_validator("ALLOWED_EXTENSIONS")
    @classmethod
    def normalize_extensions(cls, value):
        return [extension.lower() for extension in value]

    @property
    def database_url(self) -> str:
        url = self.DATABASE_URL.strip()

        if url.startswith("postgresql://"):
            return url.replace(
                "postgresql://",
                "postgresql+psycopg://",
                1
            )

        if url.startswith("postgres://"):
            return url.replace(
                "postgres://",
                "postgresql+psycopg://",
                1
            )

        return url

    def validate_settings(self):
        if self.CHUNK_SIZE <= 0:
            raise ValueError("CHUNK_SIZE must be positive")

        if not 0 <= self.CHUNK_OVERLAP < self.CHUNK_SIZE:
            raise ValueError("Invalid CHUNK_OVERLAP")

        if self.EMBEDDING_DIMENSIONS not in (256, 512, 1024):
            raise ValueError("Unsupported Titan embedding dimension")

        if self.MAX_UPLOAD_SIZE_MB <= 0:
            raise ValueError("MAX_UPLOAD_SIZE_MB must be positive")

        if self.RETRIEVAL_TOP_K <= 0:
            raise ValueError("RETRIEVAL_TOP_K must be positive")

        if not 0 <= self.SIMILARITY_THRESHOLD <= 1:
            raise ValueError("SIMILARITY_THRESHOLD must be between 0 and 1")

        if not self.ALLOWED_EXTENSIONS:
            raise ValueError("At least one file extension is required")

    def prepare_directories(self):
        self.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    configuration = Settings()
    configuration.validate_settings()
    configuration.prepare_directories()
    return configuration


settings = get_settings()

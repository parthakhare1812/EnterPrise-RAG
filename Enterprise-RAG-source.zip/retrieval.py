
from app.config import settings
from app.ingestion import generate_embedding, get_pinecone_index


def retrieve_documents(
    query: str,
    top_k: int | None = None,
    document_ids: list[str] | None = None
) -> list[dict]:
    query = query.strip()

    if not query:
        return []

    limit = top_k if top_k is not None else settings.RETRIEVAL_TOP_K

    if limit <= 0:
        raise ValueError("top_k must be positive")

    embedding = generate_embedding(query)
    index = get_pinecone_index()

    metadata_filter = None

    if document_ids:
        metadata_filter = {
            "document_id": {"$in": document_ids}
        }

    response = index.query(
        vector=embedding,
        top_k=limit,
        include_metadata=True,
        include_values=False,
        namespace=settings.PINECONE_NAMESPACE,
        filter=metadata_filter
    )

    results = []

    for match in response.matches:
        score = float(match.score or 0)

        if score < settings.SIMILARITY_THRESHOLD:
            continue

        metadata = match.metadata or {}

        results.append({
            "chunk_id": match.id,
            "document_id": metadata.get("document_id"),
            "filename": metadata.get("filename"),
            "chunk_index": metadata.get("chunk_index"),
            "text": metadata.get("text", ""),
            "score": score
        })

    return results


def prepare_context(results: list[dict]) -> str:
    if not results:
        return "No relevant documents were retrieved."

    sections = []

    for index, result in enumerate(results, start=1):
        sections.append(
            f"[Source {index}: {result.get('filename', 'Unknown')} | "
            f"Chunk {result.get('chunk_index', 'Unknown')}]\n"
            f"{result.get('text', '')}"
        )

    return "\n\n".join(sections)


def prepare_citations(results: list[dict]) -> list[dict]:
    return [
        {
            "document_id": result["document_id"],
            "filename": result["filename"],
            "chunk_index": result["chunk_index"],
            "score": round(result["score"], 4)
        }
        for result in results
    ]

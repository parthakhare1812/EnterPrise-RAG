
import logging
import time
from contextlib import contextmanager

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
    OTLPSpanExporter
)

from app.config import settings


logger = logging.getLogger("enterprise_rag")

_provider = None
tracer = trace.get_tracer("enterprise_rag")


def initialize_observability():
    global _provider, tracer

    if _provider is not None:
        return

    resource = Resource.create({
        "service.name": settings.APP_NAME,
        "deployment.environment": settings.ENVIRONMENT
    })

    _provider = TracerProvider(resource=resource)

    if settings.RIUS_ENDPOINT:
        exporter = OTLPSpanExporter(
            endpoint=settings.RIUS_ENDPOINT,
            headers=(
                {"Authorization": f"Bearer {settings.RIUS_API_KEY}"}
                if settings.RIUS_API_KEY else {}
            )
        )

        _provider.add_span_processor(
            BatchSpanProcessor(exporter)
        )

    trace.set_tracer_provider(_provider)
    tracer = trace.get_tracer("enterprise_rag")


@contextmanager
def trace_operation(name: str, attributes: dict | None = None):
    start = time.perf_counter()

    with tracer.start_as_current_span(name) as span:
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, str(value))

        try:
            yield span
        except Exception as error:
            span.record_exception(error)
            span.set_status(
                trace.Status(
                    trace.StatusCode.ERROR,
                    str(error)
                )
            )
            logger.exception("Operation failed: %s", name)
            raise
        finally:
            duration = time.perf_counter() - start
            span.set_attribute("operation.duration_seconds", duration)
            logger.info(
                "%s completed in %.3f seconds",
                name,
                duration
            )


def shutdown_observability():
    if _provider is not None:
        _provider.force_flush()
        _provider.shutdown()
